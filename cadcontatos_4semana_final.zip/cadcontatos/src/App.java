import config.*;
import controllers.ContatoController;

public class App {
    public static void main(String[] args) throws Exception {   
        ContatoController controller = new ContatoController();
        controller.iniciar();
    }
}
