package config; //indica em qual folder esta o arquivo

//importando bibliotecas sql
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.SQLException;

//cria uma class publica chamada "DbConnection" (nome do arquivo)
public class DbConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/banco_integrado_projJava?useSSL=false&serverTimezone=UTC"; //cria uma variavel estática do tipo String chamada URL e atribui o endereço do banco de dados, no caso chamado "banco_integrado_projJava"
    private static final String USER = "root"; //cria uma variavel estática do tipo String chamada USER e atribui o nome do user
    private static final String PASSWORD = ""; //cria uma variavel estática do tipo String chamada PASSWORD e atribui a senha do user

    private static Connection connection = null; //cria uma variavel connection do tipo Connection e declara ela como vazia

    //cria uma método que retorna um valor do tipo Connection
    public static Connection getConnection() throws SQLException { 

        //executa se a connection for vazia ou estiver fechada(método: isClosed())
        if (connection == null || connection.isClosed()) {

            //try e catch é uma maneira de executar garantindo que se der erro, retorne uma mensagem de erro
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Carregar o driver do MySQL(adicionado na lib)
                connection = DriverManager.getConnection (URL, USER, PASSWORD); //utiliza dos valores fornecidos (url, user, password) para acessar o banco de dados
            } catch (Exception e) {
                System.out.println("Driver do MySQL não encontrado.");//imprime uma mensagem no console para informar que o driver JDBC do MySQL não foi encontrado
                System.out.println(e.getMessage());//imprime a mensagem detalhada do erro 
                e.printStackTrace();
            }
        }
        return connection; //retorna o valor de connection
    }

    //cria método chamado disconnect que serve para fechar a conexão com o banco de dados
    public static void disconnect (Connection connection) {

        //tenta fechar a conexão com o banco de dados usando o método close()
        try {
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException("Error disconnection the database", e); //imprime a mensagem se der erro
        }
    }

}