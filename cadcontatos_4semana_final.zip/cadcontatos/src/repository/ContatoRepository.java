package repository;

import models.Contato;
import config.DbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContatoRepository {

    // cria método para criar/adicionar um novo contato no banco de dados
    public void adicionarContato(Contato contato) {
        // SQL para inserir um novo contato
        String sql = "INSERT INTO contatos (nome, email, telefone) VALUES (?, ?, ?)";

        // gerenciaa a conexão e o PreparedStatement automaticamente
        try (Connection conn = DbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            // preenche os valores nos placeholders("?")
            stmt.setString(1, contato.getNome());
            stmt.setString(2, contato.getEmail());
            stmt.setString(3, contato.getTelefone());

            //verifica se todas as linhas afetadas
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Contato adicionado com sucesso!");// se afetado exibe a mensagem de sucesso
            }

        } catch (SQLException e) {
            // captura e exibe erros relacionados ao SQL
            System.out.println("Erro ao adicionar contato!");
            e.printStackTrace();
        }
    }

    // cria método para retornar todos os contatos do banco de dados
    public List<Contato> obterTodosContatos() {
        List<Contato> contatos = new ArrayList<>(); //cria vetor/lista para armazenar os contatos
        String sql = "SELECT * FROM contatos"; // SQL para buscar todos os contatos

        // gerencia a conexão e os objetos relacionados
        try (Connection conn = DbConnection.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            // loop para percorrer o ResultSet e criar objetos Contato
            while (rs.next()) {
                Contato contato = new Contato(
                    rs.getInt("id"), // pega o ID
                    rs.getString("nome"), // pega o nome
                    rs.getString("email"), // pega o email
                    rs.getString("telefone") // pega o telefone
                );
                contatos.add(contato); //  adiciona o contato na lista
            }

        } catch (SQLException e) {
            // captura e exibe erros relacionados ao SQL
            System.out.println("Erro ao obter contatos.");
            e.printStackTrace();
        }

        return contatos; // retorna a lista de contatos
    }

    //crai método para retornar um contato pelo ID
    public Contato obterContatoPorId(int id) {
        String sql = "SELECT * FROM contatos WHERE id = ?"; // SQL para buscar o contato por ID
        Contato contato = null; //cria objeto para armazenar o contato encontrado

        // gerencia a conexão e o PreparedStatement automaticamente
        try (Connection conn = DbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            // define o ID como parâmetro da query
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery(); // executa a query

            // verifica se há resultados no ResultSet
            if (rs.next()) {
                contato = new Contato(
                    rs.getInt("id"), // pega o ID
                    rs.getString("nome"), // pega o nome
                    rs.getString("email"), // pega o email
                    rs.getString("telefone") // pega o telefone
                );
            }

        } catch (SQLException e) {
            // captura e exibe erros relacionados ao SQL
            System.out.println("Erro ao obter contato por ID");
            e.printStackTrace();
        }

        return contato; // retorna o contato encontrado ou null
    }

    // cria método para atualizar um contato existente no banco de dados
    public void atualizarContato(Contato contato) {
        // SQL para atualizar os dados do contato
        String sql = "UPDATE contatos SET nome = ?, email = ?, telefone = ? WHERE id = ?";

        // gerencia a conexão e o PreparedStatement automaticamente
        try (Connection conn = DbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            // define os valores dos campos a serem atualizados
            stmt.setString(1, contato.getNome());
            stmt.setString(2, contato.getEmail());
            stmt.setString(3, contato.getTelefone());
            stmt.setInt(4, contato.getId());

            // executa a query e verifica quantas linhas foram afetadas
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Contato atualizado com sucesso!");//exibe mensagem
            } else {
                System.out.println("Contato não encontrado.");//exibe mensagem
            }

        } catch (SQLException e) {
            // captura e exibe erros relacionados ao SQL
            System.out.println("Erro ao atualizar contato.");
            e.printStackTrace();
        }
    }

    // cria método para deletar um contato pelo ID
    public void deletarContato(int id) {
        String sql = "DELETE FROM contatos WHERE id = ?"; // SQL para deletar o contato pelo ID

        // gerencia a conexão e o PreparedStatement automaticamente
        try (Connection conn = DbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            // define o ID como parâmetro da query
            stmt.setInt(1, id);

            // executa a query e verifica quantas linhas foram afetadas
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Contato deletado com sucesso!");
            } else {
                System.out.println("Contato não encontrado.");
            }

        } catch (SQLException e) {
            // captura e exibe erros relacionados ao SQL
            System.out.println("Erro ao deletar contato.");
            e.printStackTrace();
        }
    }
}
